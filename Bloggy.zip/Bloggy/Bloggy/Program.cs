﻿using System;

namespace Bloggy
{
    class Program
    {
        static void Main(string[] args)
        {
            new App().Run();
        }
    }
}
